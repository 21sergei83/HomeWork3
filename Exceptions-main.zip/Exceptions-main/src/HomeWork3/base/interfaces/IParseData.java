package HomeWork3.base.interfaces;

public interface IParseData {
    public void parseData(String data);
}
