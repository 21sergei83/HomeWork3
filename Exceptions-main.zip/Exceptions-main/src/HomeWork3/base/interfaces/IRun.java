package HomeWork3.base.interfaces;

import java.io.IOException;

public interface IRun {
    public void run() throws IOException;
}
