package HomeWork3.base.interfaces;

public interface ICheckFullName {
    public boolean checkFullName(String[] fullName);
}
