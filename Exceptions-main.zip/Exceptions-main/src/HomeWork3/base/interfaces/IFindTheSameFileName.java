package HomeWork3.base.interfaces;

public interface IFindTheSameFileName {
    public boolean findTheSameFileName(String lastName, String pathFolder);
}
