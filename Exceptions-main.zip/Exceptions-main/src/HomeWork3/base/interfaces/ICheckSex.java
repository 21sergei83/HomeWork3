package HomeWork3.base.interfaces;

public interface ICheckSex {
    public boolean checkSex(String sex);
}
