package HomeWork3.base.interfaces;

public interface ICheckElement {
    public boolean checkElement(String data);
}
