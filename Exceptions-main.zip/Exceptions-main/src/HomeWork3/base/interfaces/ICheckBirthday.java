package HomeWork3.base.interfaces;

public interface ICheckBirthday {
    public boolean checkBirthday(String birthday);
}
