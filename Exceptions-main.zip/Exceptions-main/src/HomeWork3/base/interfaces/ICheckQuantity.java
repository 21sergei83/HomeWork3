package HomeWork3.base.interfaces;

public interface ICheckQuantity {
    public boolean checkQuantity(String[] data);
}
