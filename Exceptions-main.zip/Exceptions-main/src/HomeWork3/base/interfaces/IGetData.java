package HomeWork3.base.interfaces;

import HomeWork3.base.exceptions.GetDataException;

import java.io.IOException;

public interface IGetData {
    public String getData() throws IOException;
}
