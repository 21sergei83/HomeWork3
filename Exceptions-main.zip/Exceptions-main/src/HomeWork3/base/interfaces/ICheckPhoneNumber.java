package HomeWork3.base.interfaces;

public interface ICheckPhoneNumber {
    public boolean checkPhoneNumber();
}
