package HomeWork3.base.abstractClasses;

import HomeWork3.base.interfaces.ICheckElement;

public abstract class ACheckData implements ICheckElement {

}
