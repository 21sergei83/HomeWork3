package HomeWork3.base.abstractClasses;

import HomeWork3.base.interfaces.ICheckFullName;

public abstract class ACheckFullName implements ICheckFullName {
}
