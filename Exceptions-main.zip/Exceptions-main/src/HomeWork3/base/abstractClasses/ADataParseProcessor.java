package HomeWork3.base.abstractClasses;

import HomeWork3.base.interfaces.IGetInfo;
import HomeWork3.base.interfaces.IParseData;

public abstract class ADataParseProcessor implements IGetInfo, IParseData {
}
