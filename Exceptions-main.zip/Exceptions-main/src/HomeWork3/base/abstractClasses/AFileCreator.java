package HomeWork3.base.abstractClasses;

import HomeWork3.base.interfaces.ICreateFile;

import java.io.File;

public abstract class AFileCreator implements ICreateFile {
    protected File file;
}
