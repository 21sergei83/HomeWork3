package HomeWork3.base.abstractClasses;

import HomeWork3.base.interfaces.IGetData;

public abstract class AGetData implements IGetData {

}
