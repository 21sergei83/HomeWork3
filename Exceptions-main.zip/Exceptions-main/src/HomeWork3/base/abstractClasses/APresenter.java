package HomeWork3.base.abstractClasses;

import HomeWork3.base.interfaces.IRun;

public abstract class APresenter implements IRun {
}
